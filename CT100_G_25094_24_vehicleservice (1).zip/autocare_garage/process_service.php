<?php

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.html');
    exit;
}


$SERVICE_CATALOG = [
    'Engine Oil Change'   => 3000,
    'Brake Inspection'    => 2000,
    'Wheel Alignment'     => 2500,
    'Tyre Balancing'      => 2000,
    'Computer Diagnosis'  => 3500,
    'Full Service'        => 8000,
];

$ALLOWED_VEHICLE_TYPES = ['Saloon Car', 'SUV', 'Pickup', 'Van'];

$customer_name = isset($_POST['customer_name']) ? trim((string)$_POST['customer_name']) : '';
$phone         = isset($_POST['phone']) ? trim((string)$_POST['phone']) : '';
$email         = isset($_POST['email']) ? trim((string)$_POST['email']) : '';
$reg_number    = isset($_POST['reg_number']) ? trim((string)$_POST['reg_number']) : '';
$vehicle_type  = isset($_POST['vehicle_type']) ? trim((string)$_POST['vehicle_type']) : '';
$vehicle_model = isset($_POST['vehicle_model']) ? trim((string)$_POST['vehicle_model']) : '';
$year_raw      = isset($_POST['year']) ? trim((string)$_POST['year']) : '';
$service_date  = isset($_POST['service_date']) ? trim((string)$_POST['service_date']) : '';
$raw_services  = (isset($_POST['services']) && is_array($_POST['services'])) ? $_POST['services'] : [];

$errors = [];

if (empty($customer_name) || mb_strlen($customer_name) < 2) {
    $errors[] = 'Customer full name is required and must be at least 2 characters.';
}

if (!preg_match('/^[0-9]{10}$/', $phone)) {
    $errors[] = 'Phone number must consist of exactly 10 digits (e.g. 0712345678).';
}

if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'A valid email address is required (e.g. name@example.com).';
}

if (empty($reg_number) || mb_strlen($reg_number) < 2) {
    $errors[] = 'Vehicle registration number is required (e.g. KDA 123A).';
}

if (empty($vehicle_type) || !in_array($vehicle_type, $ALLOWED_VEHICLE_TYPES, true)) {
    $errors[] = 'Vehicle type must be one of: ' . implode(', ', $ALLOWED_VEHICLE_TYPES) . '.';
}

if (empty($vehicle_model) || mb_strlen($vehicle_model) < 2) {
    $errors[] = 'Vehicle make and model must be specified (e.g. Toyota Prado TX).';
}

$current_year = (int)date('Y');
$max_year = $current_year + 1;
if (!ctype_digit($year_raw) || (int)$year_raw < 1950 || (int)$year_raw > $max_year) {
    $errors[] = 'Vehicle year of manufacture must be a whole number between 1950 and ' . $max_year . '.';
} else {
    $year = (int)$year_raw;
}

$timestamp = strtotime($service_date);
$today_timestamp = strtotime(date('Y-m-d'));
if (!$timestamp || $timestamp === false) {
    $errors[] = 'Preferred service date is invalid.';
} elseif ($timestamp < $today_timestamp) {
    $errors[] = 'Service date cannot be in the past. Please select today or a future date.';
}

$validated_services = [];
$service_prices = [];

foreach ($raw_services as $service_candidate) {
    $clean_name = trim((string)$service_candidate);
    if (array_key_exists($clean_name, $SERVICE_CATALOG) && !isset($service_prices[$clean_name])) {
        $validated_services[] = $clean_name;
        $service_prices[$clean_name] = $SERVICE_CATALOG[$clean_name];
    }
}

if (empty($validated_services)) {
    $errors[] = 'Please select at least one valid maintenance service package.';
}

$total_cost = !empty($service_prices) ? array_sum($service_prices) : 0;

$formatted_service_date = $timestamp ? date('d F Y', $timestamp) : $service_date;

$booking_reference = 'ACG-' . date('Y') . '-' . strtoupper(substr(md5(uniqid((string)mt_rand(), true)), 0, 6));

function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo empty($errors) ? 'Service Request Received | AutoCare Garage' : 'Validation Error | AutoCare Garage'; ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,400;0,500;0,600;0,700;0,800;1,700&display=swap" rel="stylesheet">
  <style>
    :root {
      --color-charcoal: #2b2b2e;
      --color-near-black: #161618;
      --color-surface: #232326;
      --color-surface-elevated: #2f2f34;
      --color-orange: #ff6a00;
      --color-orange-hover: #e55f00;
      --color-orange-subtle: rgba(255, 106, 0, 0.12);
      --color-orange-border: rgba(255, 106, 0, 0.35);
      --color-danger: #ef4444;
      --color-danger-subtle: rgba(239, 68, 68, 0.12);
      --color-success: #10b981;
      --color-text-main: #ffffff;
      --color-text-muted: #b5b4b1;
      --color-text-subtle: #82817d;
      --color-border: #3a3a3e;
      --font-family: 'Barlow', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      --radius-sm: 6px;
      --radius-md: 10px;
      --radius-lg: 16px;
      --radius-full: 9999px;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: var(--font-family);
      background-color: var(--color-near-black);
      color: var(--color-text-main);
      line-height: 1.55;
      padding: 2.5rem 1rem;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }

    .wrapper {
      width: 100%;
      max-width: 820px;
      margin: 0 auto;
    }

    .brand-header {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.65rem;
      margin-bottom: 2rem;
      text-decoration: none;
      color: #ffffff;
      font-size: 1.5rem;
      font-weight: 800;
    }

    .brand-icon {
      width: 38px;
      height: 38px;
      background: var(--color-orange);
      border-radius: var(--radius-sm);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #ffffff;
    }

    .brand-text span {
      color: var(--color-orange);
    }

    .card {
      background-color: var(--color-surface);
      border: 1px solid var(--color-border);
      border-radius: var(--radius-lg);
      padding: 2.5rem;
      box-shadow: 0 16px 36px rgba(0, 0, 0, 0.4);
    }

    
    .error-header {
      display: flex;
      align-items: center;
      gap: 1rem;
      margin-bottom: 1.5rem;
      padding-bottom: 1.25rem;
      border-bottom: 1px solid var(--color-border);
    }

    .error-icon-box {
      width: 48px;
      height: 48px;
      border-radius: var(--radius-full);
      background: var(--color-danger-subtle);
      border: 1px solid rgba(239, 68, 68, 0.4);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--color-danger);
      flex-shrink: 0;
    }

    .error-title {
      font-size: 1.5rem;
      font-weight: 800;
      color: #ffffff;
    }

    .error-list {
      list-style: none;
      display: flex;
      flex-direction: column;
      gap: 0.85rem;
      margin-bottom: 2rem;
    }

    .error-list li {
      background-color: var(--color-surface-elevated);
      border-left: 3px solid var(--color-danger);
      padding: 0.85rem 1.1rem;
      border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
      font-size: 0.95rem;
      color: #fca5a5;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    
    .status-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      background: rgba(16, 185, 129, 0.12);
      border: 1px solid rgba(16, 185, 129, 0.35);
      color: #34d399;
      padding: 0.35rem 0.85rem;
      border-radius: var(--radius-full);
      font-size: 0.82rem;
      font-weight: 700;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      margin-bottom: 1rem;
    }

    .confirmation-title {
      font-size: 2.1rem;
      font-weight: 800;
      letter-spacing: -0.02em;
      color: #ffffff;
      margin-bottom: 0.5rem;
      line-height: 1.2;
    }

    .ref-banner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 1rem;
      background: var(--color-surface-elevated);
      border: 1px solid var(--color-border);
      border-radius: var(--radius-md);
      padding: 1rem 1.25rem;
      margin: 1.5rem 0 2rem 0;
    }

    .ref-label {
      font-size: 0.85rem;
      color: var(--color-text-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      font-weight: 700;
    }

    .ref-code {
      font-size: 1.25rem;
      font-weight: 800;
      color: var(--color-orange);
      font-family: monospace;
      letter-spacing: 0.05em;
    }

    .details-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .detail-group {
      background-color: var(--color-surface-elevated);
      border: 1px solid var(--color-border);
      border-radius: var(--radius-md);
      padding: 1.25rem;
    }

    .group-heading {
      font-size: 0.82rem;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--color-orange);
      font-weight: 700;
      margin-bottom: 0.85rem;
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      font-size: 0.95rem;
      padding: 0.35rem 0;
      border-bottom: 1px dashed rgba(255, 255, 255, 0.08);
    }

    .info-row:last-child {
      border-bottom: none;
    }

    .info-label {
      color: var(--color-text-muted);
    }

    .info-val {
      font-weight: 600;
      color: #ffffff;
      text-align: right;
    }

    
    .services-table-wrap {
      margin-bottom: 2rem;
    }

    .services-table-title {
      font-size: 1.15rem;
      font-weight: 700;
      margin-bottom: 0.75rem;
      color: #ffffff;
    }

    .services-table {
      width: 100%;
      border-collapse: collapse;
      background-color: var(--color-surface-elevated);
      border: 1px solid var(--color-border);
      border-radius: var(--radius-md);
      overflow: hidden;
    }

    .services-table th, .services-table td {
      padding: 0.85rem 1.25rem;
      text-align: left;
    }

    .services-table th {
      background-color: rgba(0, 0, 0, 0.25);
      font-size: 0.82rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: var(--color-text-muted);
      border-bottom: 1px solid var(--color-border);
    }

    .services-table td {
      font-size: 0.95rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }

    .services-table tr:last-child td {
      border-bottom: none;
    }

    .price-col {
      text-align: right !important;
      font-weight: 700;
      color: var(--color-orange);
      font-variant-numeric: tabular-nums;
    }

    
    .total-banner {
      background: linear-gradient(135deg, rgba(255, 106, 0, 0.15) 0%, rgba(255, 106, 0, 0.05) 100%);
      border: 1px solid var(--color-orange-border);
      border-radius: var(--radius-md);
      padding: 1.25rem 1.5rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 2rem;
    }

    .total-title {
      font-size: 1rem;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #ffffff;
    }

    .total-figure {
      font-size: 2rem;
      font-weight: 800;
      color: var(--color-orange);
      font-variant-numeric: tabular-nums;
      letter-spacing: -0.01em;
    }

    
    .next-steps-box {
      background-color: var(--color-surface-elevated);
      border: 1px solid var(--color-border);
      border-radius: var(--radius-md);
      padding: 1.25rem;
      margin-bottom: 2.25rem;
      font-size: 0.9rem;
      color: var(--color-text-muted);
      line-height: 1.5;
    }

    .next-steps-box strong {
      color: #ffffff;
    }

    
    .btn-row {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      padding: 0.85rem 1.75rem;
      font-size: 0.95rem;
      font-weight: 700;
      border-radius: var(--radius-md);
      cursor: pointer;
      border: 1px solid transparent;
      text-decoration: none;
      transition: all 0.2s ease;
    }

    .btn-primary {
      background-color: var(--color-orange);
      color: #ffffff;
      box-shadow: 0 4px 14px rgba(255, 106, 0, 0.35);
    }

    .btn-primary:hover {
      background-color: var(--color-orange-hover);
      transform: translateY(-1px);
    }

    .btn-secondary {
      background-color: var(--color-surface-elevated);
      color: #ffffff;
      border-color: var(--color-border);
    }

    .btn-secondary:hover {
      border-color: #ffffff;
    }

    @media (max-width: 640px) {
      .details-grid {
        grid-template-columns: 1fr;
      }
      .card {
        padding: 1.5rem;
      }
      .confirmation-title {
        font-size: 1.65rem;
      }
      .total-banner {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
      }
    }
  </style>
</head>
<body>

  <div class="wrapper">
    
    <a href="index.html" class="brand-header">
      <div class="brand-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
        </svg>
      </div>
      <span class="brand-text">AutoCare <span>Garage</span></span>
    </a>

    <?php if (!empty($errors)): ?>
      
      <main class="card">
        <div class="error-header">
          <div class="error-icon-box">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="8" x2="12" y2="12"></line>
              <line x1="12" y1="16" x2="12.01" y2="16"></line>
            </svg>
          </div>
          <div>
            <h1 class="error-title">Submission Incomplete</h1>
            <p style="color: var(--color-text-muted); font-size: 0.95rem;">Please review and resolve the following errors:</p>
          </div>
        </div>

        <ul class="error-list">
          <?php foreach ($errors as $err): ?>
            <li>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span><?php echo e($err); ?></span>
            </li>
          <?php endforeach; ?>
        </ul>

        <div class="btn-row">
          <button type="button" onclick="window.history.back();" class="btn btn-primary">
            &larr; Go Back &amp; Correct Details
          </button>
          <a href="index.html" class="btn btn-secondary">
            Return to Homepage
          </a>
        </div>
      </main>

    <?php else: ?>
      
      <main class="card">
        <div class="status-badge">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          Booking Confirmed &amp; Bay Reserved
        </div>

        <h1 class="confirmation-title">SERVICE REQUEST RECEIVED</h1>
        <p style="color: var(--color-text-muted); font-size: 1.05rem;">
          Thank you, <strong><?php echo e($customer_name); ?></strong>. Your vehicle service request has been registered in the AutoCare Garage workshop queue.
        </p>

        
        <div class="ref-banner">
          <div>
            <div class="ref-label">Booking Reference Number</div>
            <div class="ref-code"><?php echo e($booking_reference); ?></div>
          </div>
          <div style="font-size: 0.85rem; color: var(--color-text-muted);">
            Booked on: <?php echo date('d M Y, H:i'); ?>
          </div>
        </div>

        
        <div class="details-grid">
          
          <div class="detail-group">
            <div class="group-heading">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
              Customer Information
            </div>
            <div class="info-row">
              <span class="info-label">Customer Name</span>
              <span class="info-val"><?php echo e($customer_name); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">Phone</span>
              <span class="info-val"><?php echo e($phone); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">Email</span>
              <span class="info-val"><?php echo e($email); ?></span>
            </div>
          </div>

          
          <div class="detail-group">
            <div class="group-heading">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="1" y="5" width="22" height="14" rx="2"></rect><circle cx="7" cy="14" r="2"></circle><circle cx="17" cy="14" r="2"></circle></svg>
              Vehicle &amp; Appointment
            </div>
            <div class="info-row">
              <span class="info-label">Vehicle Registration</span>
              <span class="info-val" style="color: var(--color-orange); letter-spacing: 0.05em; font-weight: 800;">
                <?php echo e(strtoupper($reg_number)); ?>
              </span>
            </div>
            <div class="info-row">
              <span class="info-label">Vehicle Type</span>
              <span class="info-val"><?php echo e($vehicle_type); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">Model &amp; Year</span>
              <span class="info-val"><?php echo e($vehicle_model); ?> (<?php echo e($year); ?>)</span>
            </div>
            <div class="info-row">
              <span class="info-label">Service Date</span>
              <span class="info-val"><?php echo e($formatted_service_date); ?></span>
            </div>
          </div>
        </div>

        
        <div class="services-table-wrap">
          <h2 class="services-table-title">Selected Maintenance Services</h2>
          <table class="services-table">
            <thead>
              <tr>
                <th>Service Description</th>
                <th class="price-col">Price (KSh)</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($validated_services as $srv): ?>
                <tr>
                  <td><?php echo e($srv); ?></td>
                  <td class="price-col">KSh <?php echo number_format($service_prices[$srv]); ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        
        <div class="total-banner">
          <div>
            <div class="total-title">ESTIMATED SERVICE COST</div>
            <div style="font-size: 0.85rem; color: var(--color-text-muted);">
              Calculated upfront from verified workshop price catalog
            </div>
          </div>
          <div class="total-figure">
            KSh <?php echo number_format($total_cost); ?>
          </div>
        </div>

        
        <div class="next-steps-box">
          <strong>Next Steps &amp; Workshop Arrival:</strong><br>
          Our service advisor will contact you at <strong><?php echo e($phone); ?></strong> within 2 business hours to confirm your scheduled bay slot for <strong><?php echo e($formatted_service_date); ?></strong>. Please arrive 15 minutes before your time at our Industrial Area center (Enterprise Road). Payment is due only upon completion of maintenance via M-Pesa or Card.
        </div>

        
        <div class="btn-row">
          <a href="booking.html" class="btn btn-primary">
            Make Another Booking
          </a>
          <a href="index.html" class="btn btn-secondary">
            Return to Home
          </a>
          <button type="button" onclick="window.print();" class="btn btn-secondary">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
            Print Confirmation
          </button>
        </div>
      </main>
    <?php endif; ?>
  </div>

</body>
</html>
