
const VEHICLE_TYPE_TIPS = {
  'Saloon Car': '💡 Saloon Car Tip: Regular synthetic oil changes and 3D laser alignment ensure optimal highway fuel efficiency and tire longevity.',
  'SUV': '💡 SUV Tip: Recommended for 4WD & AWD drivetrains. We inspect transfer cases, differential oils, heavy-duty suspension bushings, and all-terrain tire wear.',
  'Pickup': '💡 Pickup / Commercial Tip: High-load vehicles require frequent brake pad wear checks, rear leaf spring inspections, and differential servicing.',
  'Van': '💡 Van / Fleet Tip: Priority cooling system pressure check, high-load transmission fluid inspection, and commercial load-rated tyre balancing.'
};

document.addEventListener('DOMContentLoaded', function() {

  const bookingForm = document.getElementById('bookingForm');
  const customerNameInput = document.getElementById('customer_name');
  const phoneInput = document.getElementById('phone');
  const emailInput = document.getElementById('email');
  const regNumberInput = document.getElementById('reg_number');
  const vehicleTypeSelect = document.getElementById('vehicle_type');
  const vehicleModelInput = document.getElementById('vehicle_model');
  const yearInput = document.getElementById('year');
  const serviceDateInput = document.getElementById('service_date');
  const serviceCheckboxes = document.querySelectorAll('input[name="services[]"]');

  const vehicleTypeTipBox = document.getElementById('vehicleTypeTip');
  const vehicleAgeWarningBox = document.getElementById('vehicleAgeWarning');
  const diagBadge = document.getElementById('diagBadge');

  const estimateList = document.getElementById('estimateList');
  const estimateTotalEl = document.getElementById('estimateTotal');
  const selectedCountText = document.getElementById('selectedCountText');
  const estimateVehicleName = document.getElementById('estimateVehicleName');
  const estimateVehicleSub = document.getElementById('estimateVehicleSub');

  const themeToggleBtn = document.getElementById('themeToggleBtn');
  const sunIcon = document.getElementById('sunIcon');
  const moonIcon = document.getElementById('moonIcon');
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const mobileNavMenu = document.getElementById('mobileNavMenu');

  const currentYear = new Date().getFullYear();
  const maxAllowedYear = currentYear + 1;
  if (yearInput) {
    yearInput.setAttribute('max', maxAllowedYear.toString());
  }

  const todayStr = new Date().toISOString().split('T')[0];
  if (serviceDateInput) {
    serviceDateInput.setAttribute('min', todayStr);
  }

  
  function formatKSh(amount) {
    return 'KSh ' + Number(amount).toLocaleString('en-KE');
  }

  
  function calculateServiceCost() {
    let total = 0;
    if (serviceCheckboxes) {
      serviceCheckboxes.forEach(cb => {
        if (cb.checked) {
          const price = parseFloat(cb.dataset.price) || 0;
          total += price;
        }
      });
    }
    return total;
  }

  
  function checkVehicleAge() {
    if (!yearInput || !vehicleAgeWarningBox) return;
    const yearVal = parseInt(yearInput.value, 10);
    if (!isNaN(yearVal) && yearVal >= 1950 && yearVal < 2005) {
      vehicleAgeWarningBox.innerHTML = '⚠️ <strong>Vehicle Age Notice (' + yearVal + '):</strong> Vehicles built before 2005 require comprehensive electrical & sensor health checks. We strongly recommend pairing your service with <strong>Computer Diagnosis</strong>.';
      vehicleAgeWarningBox.style.display = 'block';
      if (diagBadge) {
        diagBadge.style.display = 'inline-block';
      }
    } else {
      vehicleAgeWarningBox.style.display = 'none';
      if (diagBadge) {
        diagBadge.style.display = 'none';
      }
    }
  }

  
  function updateEstimate() {
    if (!estimateList || !estimateTotalEl) return;

    const selected = [];
    if (serviceCheckboxes) {
      serviceCheckboxes.forEach(cb => {
        if (cb.checked) {
          selected.push({
            name: cb.value,
            price: parseFloat(cb.dataset.price) || 0
          });
        }
      });
    }

    const count = selected.length;
    if (selectedCountText) {
      selectedCountText.textContent = count === 1 ? '1 service selected' : count + ' services selected';
    }

    if (selected.length === 0) {
      estimateList.innerHTML = `
        <li class="estimate-empty-state">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin-bottom: 0.5rem; opacity: 0.6;">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
          </svg>
          Select one or more services from the checklist on the left to calculate your live estimate.
        </li>
      `;
    } else {
      let listHtml = '';
      selected.forEach(item => {
        listHtml += `
          <li class="estimate-item">
            <span>${item.name}</span>
            <span class="estimate-item-price">${formatKSh(item.price)}</span>
          </li>
        `;
      });
      estimateList.innerHTML = listHtml;
    }

    const total = calculateServiceCost();
    const currentFormatted = formatKSh(total);

    if (estimateTotalEl.textContent !== currentFormatted) {
      estimateTotalEl.textContent = currentFormatted;
      estimateTotalEl.classList.remove('animate-pulse-total');
      void estimateTotalEl.offsetWidth;
      estimateTotalEl.classList.add('animate-pulse-total');
    }

    if (estimateVehicleName && estimateVehicleSub) {
      const model = vehicleModelInput ? vehicleModelInput.value.trim() : '';
      const reg = regNumberInput ? regNumberInput.value.trim().toUpperCase() : '';
      const type = vehicleTypeSelect ? vehicleTypeSelect.value : '';
      const year = yearInput ? yearInput.value.trim() : '';

      if (model || reg || type) {
        estimateVehicleName.textContent = (year ? year + ' ' : '') + (model || 'Vehicle') + (reg ? ' (' + reg + ')' : '');
        estimateVehicleSub.textContent = type ? type + ' Category' : 'Service Bay Scheduled';
      } else {
        estimateVehicleName.textContent = 'Vehicle: Not specified';
        estimateVehicleSub.textContent = 'Fill vehicle details to customize';
      }
    }
  }

  function setFieldError(inputEl, errorEl, message) {
    if (inputEl) {
      inputEl.classList.add('is-invalid');
    }
    if (errorEl) {
      errorEl.textContent = message;
      errorEl.classList.add('visible');
    }
  }

  function clearFieldError(inputEl, errorEl) {
    if (inputEl) {
      inputEl.classList.remove('is-invalid');
    }
    if (errorEl) {
      errorEl.classList.remove('visible');
    }
  }

  function validateName() {
    if (!customerNameInput) return true;
    const val = customerNameInput.value.trim();
    const err = document.getElementById('nameError');
    if (!val || val.length < 2) {
      setFieldError(customerNameInput, err, 'Please enter your full name (minimum 2 letters).');
      return false;
    }
    clearFieldError(customerNameInput, err);
    return true;
  }

  function validatePhone() {
    if (!phoneInput) return true;
    const val = phoneInput.value.trim();
    const err = document.getElementById('phoneError');
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(val)) {
      setFieldError(phoneInput, err, 'Phone number must be exactly 10 digits (e.g. 0712345678).');
      return false;
    }
    clearFieldError(phoneInput, err);
    return true;
  }

  function validateEmail() {
    if (!emailInput) return true;
    const val = emailInput.value.trim();
    const err = document.getElementById('emailError');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(val)) {
      setFieldError(emailInput, err, 'Please enter a valid email address (e.g. name@example.com).');
      return false;
    }
    clearFieldError(emailInput, err);
    return true;
  }

  function validateRegNumber() {
    if (!regNumberInput) return true;
    const val = regNumberInput.value.trim();
    const err = document.getElementById('regError');
    if (!val || val.length < 2) {
      setFieldError(regNumberInput, err, 'Registration number is required (e.g. KDA 123A).');
      return false;
    }
    clearFieldError(regNumberInput, err);
    return true;
  }

  function validateVehicleType() {
    if (!vehicleTypeSelect) return true;
    const val = vehicleTypeSelect.value;
    const err = document.getElementById('typeError');
    const allowed = ['Saloon Car', 'SUV', 'Pickup', 'Van'];
    if (!allowed.includes(val)) {
      setFieldError(vehicleTypeSelect, err, 'Please select a valid vehicle type.');
      return false;
    }
    clearFieldError(vehicleTypeSelect, err);
    return true;
  }

  function validateVehicleModel() {
    if (!vehicleModelInput) return true;
    const val = vehicleModelInput.value.trim();
    const err = document.getElementById('modelError');
    if (!val || val.length < 2) {
      setFieldError(vehicleModelInput, err, 'Please specify vehicle make and model (e.g. Toyota Prado).');
      return false;
    }
    clearFieldError(vehicleModelInput, err);
    return true;
  }

  function validateYear() {
    if (!yearInput) return true;
    const val = parseInt(yearInput.value.trim(), 10);
    const err = document.getElementById('yearError');
    if (isNaN(val) || val < 1950 || val > maxAllowedYear) {
      setFieldError(yearInput, err, 'Year must be a whole number between 1950 and ' + maxAllowedYear + '.');
      return false;
    }
    clearFieldError(yearInput, err);
    return true;
  }

  function validateServiceDate() {
    if (!serviceDateInput) return true;
    const val = serviceDateInput.value;
    const err = document.getElementById('dateError');
    if (!val) {
      setFieldError(serviceDateInput, err, 'Please select your preferred service date.');
      return false;
    }
    const selectedDate = new Date(val + 'T00:00:00');
    const todayDate = new Date(todayStr + 'T00:00:00');
    if (isNaN(selectedDate.getTime()) || selectedDate < todayDate) {
      setFieldError(serviceDateInput, err, 'Service date cannot be in the past.');
      return false;
    }
    clearFieldError(serviceDateInput, err);
    return true;
  }

  function validateServicesSelected() {
    const err = document.getElementById('servicesError');
    if (!serviceCheckboxes || serviceCheckboxes.length === 0) return true;
    const checkedBoxes = Array.from(serviceCheckboxes).filter(cb => cb.checked);
    if (checkedBoxes.length === 0) {
      if (err) err.classList.add('visible');
      return false;
    }
    if (err) err.classList.remove('visible');
    return true;
  }

  
  function validateServiceForm(event) {
    let isValid = true;
    let firstInvalidEl = null;

    const validations = [
      { validate: validateName, element: customerNameInput },
      { validate: validatePhone, element: phoneInput },
      { validate: validateEmail, element: emailInput },
      { validate: validateRegNumber, element: regNumberInput },
      { validate: validateVehicleType, element: vehicleTypeSelect },
      { validate: validateVehicleModel, element: vehicleModelInput },
      { validate: validateYear, element: yearInput },
      { validate: validateServiceDate, element: serviceDateInput },
      { validate: validateServicesSelected, element: serviceCheckboxes ? serviceCheckboxes[0] : null }
    ];

    validations.forEach(({ validate, element }) => {
      if (element) {
        const fieldOk = validate();
        if (!fieldOk) {
          isValid = false;
          if (!firstInvalidEl) {
            firstInvalidEl = element;
          }
        }
      }
    });

    if (!isValid) {
      event.preventDefault();
      if (firstInvalidEl) {
        firstInvalidEl.focus();
        firstInvalidEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return false;
    }

    return true;
  }




  if (bookingForm) {
    bookingForm.addEventListener('submit', function(e) {
      validateServiceForm(e);
    });
  }

  if (customerNameInput) {
    customerNameInput.addEventListener('blur', validateName);
    customerNameInput.addEventListener('input', function() {
      if (customerNameInput.classList.contains('is-invalid')) validateName();
    });
  }

  if (phoneInput) {
    phoneInput.addEventListener('blur', validatePhone);
    phoneInput.addEventListener('input', function() {
      this.value = this.value.replace(/[^0-9]/g, '');
      if (phoneInput.classList.contains('is-invalid')) validatePhone();
    });
  }

  if (emailInput) {
    emailInput.addEventListener('blur', validateEmail);
    emailInput.addEventListener('input', function() {
      if (emailInput.classList.contains('is-invalid')) validateEmail();
    });
  }

  if (regNumberInput) {
    regNumberInput.addEventListener('blur', validateRegNumber);
    regNumberInput.addEventListener('input', function() {
      updateEstimate();
      if (regNumberInput.classList.contains('is-invalid')) validateRegNumber();
    });
  }

  if (vehicleModelInput) {
    vehicleModelInput.addEventListener('blur', validateVehicleModel);
    vehicleModelInput.addEventListener('input', function() {
      updateEstimate();
      if (vehicleModelInput.classList.contains('is-invalid')) validateVehicleModel();
    });
  }

  if (yearInput) {
    yearInput.addEventListener('blur', validateYear);
    yearInput.addEventListener('input', function() {
      checkVehicleAge();
      updateEstimate();
      if (yearInput.classList.contains('is-invalid')) validateYear();
    });
  }

  if (serviceDateInput) {
    serviceDateInput.addEventListener('blur', validateServiceDate);
    serviceDateInput.addEventListener('change', function() {
      validateServiceDate();
    });
  }

  if (vehicleTypeSelect) {
    vehicleTypeSelect.addEventListener('change', function() {
      validateVehicleType();
      const type = this.value;
      if (vehicleTypeTipBox) {
        if (VEHICLE_TYPE_TIPS[type]) {
          vehicleTypeTipBox.innerHTML = VEHICLE_TYPE_TIPS[type];
          vehicleTypeTipBox.style.display = 'block';
        } else {
          vehicleTypeTipBox.style.display = 'none';
        }
      }
      updateEstimate();
    });
  }

  if (serviceCheckboxes) {
    serviceCheckboxes.forEach(cb => {
      cb.addEventListener('change', function() {
        validateServicesSelected();
        updateEstimate();
      });
    });
  }

  document.querySelectorAll('.quick-select-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const serviceName = this.dataset.serviceName;
      if (serviceCheckboxes) {
        const matchingCb = Array.from(serviceCheckboxes).find(cb => cb.value === serviceName);
        if (matchingCb) {
          matchingCb.checked = true;
          validateServicesSelected();
          updateEstimate();
          const bookingSec = document.getElementById('booking');
          if (bookingSec) {
            bookingSec.scrollIntoView({ behavior: 'smooth' });
          }
        }
      }
    });
  });

  function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('autocare_theme', theme);
    if (sunIcon && moonIcon) {
      if (theme === 'light') {
        sunIcon.style.display = 'none';
        moonIcon.style.display = 'block';
      } else {
        sunIcon.style.display = 'block';
        moonIcon.style.display = 'none';
      }
    }
  }

  const savedTheme = localStorage.getItem('autocare_theme') || 'dark';
  setTheme(savedTheme);

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', function() {
      const currentTheme = document.documentElement.getAttribute('data-theme');
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      setTheme(newTheme);
    });
  }

  if (hamburgerBtn && mobileNavMenu) {
    hamburgerBtn.addEventListener('click', function() {
      const isOpen = mobileNavMenu.classList.toggle('open');
      this.setAttribute('aria-expanded', isOpen);
    });

    document.querySelectorAll('.mobile-link').forEach(link => {
      link.addEventListener('click', function() {
        mobileNavMenu.classList.remove('open');
        hamburgerBtn.setAttribute('aria-expanded', 'false');
      });
    });
  }

  document.querySelectorAll('.faq-question-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const item = this.closest('.faq-item');
      if (!item) return;
      const isActive = item.classList.contains('active');

      document.querySelectorAll('.faq-item').forEach(other => {
        other.classList.remove('active');
        const otherBtn = other.querySelector('.faq-question-btn');
        if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
      });

      if (!isActive) {
        item.classList.add('active');
        this.setAttribute('aria-expanded', 'true');
      }
    });
  });

  updateEstimate();
});
